#
# The content of this file will be filled in with meaningful data
# when creating an archive using `git archive` or by downloading an
# archive from github, e.g. from github.com/.../archive/develop.zip
#
rev = "97ce49bad"     # abbreviated commit hash
commit = "97ce49baddf18c33e434e47015ea1c6bebe8075d"  # commit hash
date = "2017-11-17 15:13:14 +0100"   # commit date
author = "Hartmut Goebel <h.goebel@crazy-compilers.com>"
ref_names = "HEAD -> develop"  # incl. current branch
commit_message = """Merge new development guide.
"""
